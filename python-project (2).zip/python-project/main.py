# ==================================
# PROGRAM APLIKASI KASIR RESTORAN
# ==================================

print("================================")
print("     APLIKASI KASIR RESTORAN")
print("================================")

# Daftar menu makanan
menu = {
    1: ("Nasi Goreng", 25000),
    2: ("Mie Ayam", 15000),
    3: ("Ayam Geprek", 20000),
    4: ("Sate Ayam", 30000),
    5: ("Bakso", 18000)
}

# Variabel total belanja
total = 0
pesanan = []

# Perulangan pemesanan
while True:
    print("\n========== MENU MAKANAN ==========")

    for nomor, (nama, harga) in menu.items():
        print(f"{nomor}. {nama} - Rp{harga:,}")

    print("0. Selesai Memilih")
    print("==================================")

    pilihan = int(input("Pilih menu (0-5): "))

    # Mengecek pilihan selesai
    if pilihan == 0:
        break

    # Mengecek pilihan menu
    elif pilihan in menu:
        nama, harga = menu[pilihan]

        jumlah = int(input("Masukkan jumlah pesanan: "))

        if jumlah <= 0:
            print("Jumlah pesanan harus lebih dari 0!")
            continue

        subtotal = harga * jumlah
        total += subtotal

        pesanan.append((nama, harga, jumlah, subtotal))

        print(f"{nama} berhasil ditambahkan!")
        print(f"Subtotal: Rp{subtotal:,}")
        print(f"Total sementara: Rp{total:,}")

    else:
        print("Pilihan menu tidak tersedia!")

# ==================================
# PERHITUNGAN DISKON
# ==================================

if total > 200000:
    diskon = 20
    potongan = total * 20 / 100
else:
    diskon = 0
    potongan = 0

total_bayar = total - potongan

# ==================================
# STRUK PEMBAYARAN
# ==================================

print("\n====================================")
print("         STRUK PEMBAYARAN")
print("====================================")

for nama, harga, jumlah, subtotal in pesanan:
    print(f"{nama}")
    print(f"  {jumlah} x Rp{harga:,} = Rp{subtotal:,}")

print("------------------------------------")
print(f"Total Belanja : Rp{total:,}")
print(f"Diskon        : {diskon}%")
print(f"Potongan      : Rp{potongan:,.0f}")
print("------------------------------------")
print(f"TOTAL BAYAR   : Rp{total_bayar:,.0f}")
print("====================================")
print("        TERIMA KASIH!")
print("====================================")
